﻿@echo off
chcp 65001 >nul
title Dangoo 本地助手
cd /d "%~dp0"

set "PYIN=%~dp0python-runtime\python.exe"

echo ============================================
echo   Dangoo 本地助手启动中...
echo   本窗口需保持打开, 关闭窗口即停止助手
echo ============================================
echo.

if exist "%PYIN%" (
  "%PYIN%" assistant_server.py
) else (
  where py >nul 2>nul
  if not errorlevel 1 (
    py assistant_server.py
  ) else (
    where python >nul 2>nul
    if not errorlevel 1 (
      python assistant_server.py
    ) else (
      echo [错误] 找不到 Python 运行环境, 请重新下载完整压缩包。
    )
  )
)

echo.
echo 助手已停止, 按任意键关闭窗口。
pause >nul
