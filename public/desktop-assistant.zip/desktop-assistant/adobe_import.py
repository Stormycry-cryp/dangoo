# -*- coding: utf-8 -*-
"""
Adobe 桌面自动化（Photoshop / Illustrator）—— 零第三方依赖。

助手本体跨平台运行，但 Adobe 自动化仅在 Windows + 已安装对应软件时可用。
实现方式：生成一段临时 PowerShell 脚本，经 COM 调用 Adobe 官方脚本接口：
    Photoshop.Application   /   Illustrator.Application
- Photoshop：有活动文档时把每张图「置入(Place)」为新图层；没有活动文档时
  先打开第一张，其余继续置入。
- Illustrator：有活动文档时 Place 到当前画板，否则逐张 Open 为新文档。

COM 是 Adobe 随软件注册的官方接口，不需要安装 Photoshop 脚本 SDK。
任何一步失败，PowerShell 以「CODE: <机器码> | <原始信息>」首行打印，
本模块据此映射成前端认识的错误码。
"""
import os
import subprocess
import tempfile

# Windows 进程名（用于轻量探测，不启动 Adobe）
ADOBE_PROCESSES = {
    "photoshop": ("Photoshop.exe",),
    "illustrator": ("Illustrator.exe",),
}

# COM ProgID（版本无关，装了对应软件即注册）
ADOBE_PROG_ID = {
    "photoshop": "Photoshop.Application",
    "illustrator": "Illustrator.Application",
}

SUPPORTED = ("photoshop", "illustrator")

# PowerShell 执行超时（秒）。COM 首次连接可能启动 Adobe，给足时间。
_PS_TIMEOUT = 180


class AdobeImportError(Exception):
    def __init__(self, code: str, message: str = ""):
        super().__init__(message or code)
        self.code = code
        self.message = message or code


def detect_adobe(application: str) -> dict:
    """轻量检测：仅看进程是否在跑，不启动 Adobe。非 Windows 直接标记不支持。"""
    app = (application or "").strip().lower()
    if app not in SUPPORTED:
        return {"running": False, "platform_supported": False, "code": "invalid_application"}
    if os.name != "nt":
        return {"running": False, "platform_supported": False}
    try:
        out = subprocess.run(
            ["tasklist", "/FO", "CSV", "/NH"],
            capture_output=True, text=True, timeout=20,
        ).stdout.lower()
        running = any(proc.lower() in out for proc in ADOBE_PROCESSES[app])
        return {"running": running, "platform_supported": True}
    except Exception as exc:  # tasklist 异常时不阻断，交给导入阶段的 COM 报错
        return {"running": False, "platform_supported": True, "code": "detect_failed", "message": str(exc)}


def _powershell_available() -> bool:
    if os.name != "nt":
        return False
    try:
        subprocess.run(
            ["powershell", "-NoProfile", "-Command", "exit 0"],
            capture_output=True, timeout=20,
        )
        return True
    except Exception:
        return False


def _build_ps_script(application: str) -> str:
    # 单引号字符串在 PowerShell 里不做插值，路径里的反斜杠/空格都安全。
    if application == "photoshop":
        body = r"""
$ErrorActionPreference = 'Stop'
try {
    $app = New-Object -ComObject 'PROGID'
} catch {
    Write-Output 'CODE: app_not_running | 无法连接 Photoshop（未安装或未正确注册）'
    exit 1
}
try {
    $placed = 0
    foreach ($p in $Paths) {
        if (-not (Test-Path -LiteralPath $p)) {
            Write-Output ('CODE: image_not_found | ' + $p)
            exit 1
        }
        $f = Get-Item -LiteralPath $p
        if ($null -eq $app.Documents -or $app.Documents.Count -eq 0) {
            $app.Open($f.FullName) | Out-Null
        } else {
            $app.ActiveDocument.Place($f.FullName) | Out-Null
        }
        $placed++
    }
    Write-Output ('OK: ' + $placed)
    exit 0
} catch {
    $msg = $_.Exception.Message
    if ($msg -match 'document' -or $msg -match 'No active') {
        Write-Output ('CODE: no_active_document | ' + $msg)
    } else {
        Write-Output ('CODE: adobe_error | ' + $msg)
    }
    exit 1
}
"""
    else:  # illustrator
        body = r"""
$ErrorActionPreference = 'Stop'
try {
    $app = New-Object -ComObject 'PROGID'
} catch {
    Write-Output 'CODE: app_not_running | 无法连接 Illustrator（未安装或未正确注册）'
    exit 1
}
try {
    $done = 0
    foreach ($p in $Paths) {
        if (-not (Test-Path -LiteralPath $p)) {
            Write-Output ('CODE: image_not_found | ' + $p)
            exit 1
        }
        $f = Get-Item -LiteralPath $p
        if ($null -eq $app.Documents -or $app.Documents.Count -eq 0) {
            $app.Open($f.FullName) | Out-Null
        } else {
            try {
                $app.ActiveDocument.Place($f.FullName) | Out-Null
            } catch {
                $app.Open($f.FullName) | Out-Null
            }
        }
        $done++
    }
    Write-Output ('OK: ' + $done)
    exit 0
} catch {
    $msg = $_.Exception.Message
    if ($msg -match 'document') {
        Write-Output ('CODE: no_active_document | ' + $msg)
    } else {
        Write-Output ('CODE: adobe_error | ' + $msg)
    }
    exit 1
}
"""
    body = body.replace("PROGID", ADOBE_PROG_ID[application])
    head = r"""
param([Parameter(ValueFromRemainingArguments=$true)][string[]]$Paths)
"""
    return head + body


def _run_com(application: str, paths: list) -> None:
    """执行 PowerShell COM 自动化；失败抛 AdobeImportError（带前端错误码）。"""
    with tempfile.NamedTemporaryFile("w", suffix=".ps1", delete=False, encoding="utf-8") as sf:
        sf.write(_build_ps_script(application))
        script_path = sf.name
    try:
        proc = subprocess.run(
            ["powershell", "-NoProfile", "-ExecutionPolicy", "Bypass", "-File", script_path] + paths,
            capture_output=True, text=True, timeout=_PS_TIMEOUT,
        )
    except subprocess.TimeoutExpired:
        raise AdobeImportError("timeout", "Adobe 响应超时")
    except FileNotFoundError:
        raise AdobeImportError("powershell_unavailable", "找不到 Windows PowerShell")
    finally:
        try:
            os.remove(script_path)
        except OSError:
            pass

    out = (proc.stdout or "").strip()
    err = (proc.stderr or "").strip()
    if proc.returncode == 0 and out.startswith("OK:"):
        return
    # 解析首行 CODE: <code> | <message>
    first = out.splitlines()[0] if out else ""
    if first.startswith("CODE:"):
        payload = first[len("CODE:"):].strip()
        if "|" in payload:
            code, message = payload.split("|", 1)
            raise AdobeImportError(code.strip(), message.strip())
        raise AdobeImportError(payload.strip(), payload.strip())
    raise AdobeImportError("adobe_error", err or out or "Adobe 自动化失败")


def import_images_to_adobe(application: str, paths: list) -> dict:
    """把已下载到本地的图片导入目标 Adobe 应用。

    返回 {ok, imported, code?, message?}。仅接受图片，视频在此阶段被剔除。
    """
    app = (application or "").strip().lower()
    if app not in SUPPORTED:
        raise AdobeImportError("invalid_application", "不支持的 Adobe 应用: %r" % application)
    if os.name != "nt":
        raise AdobeImportError("unsupported_platform", "Adobe 导入仅支持 Windows")
    if not paths:
        raise AdobeImportError("no_media", "没有可导入的图片")
    if not _powershell_available():
        raise AdobeImportError("powershell_unavailable", "本机缺少 Windows PowerShell")

    _run_com(app, paths)
    return {
        "ok": True,
        "application": app,
        "imported": [{"name": os.path.basename(p), "ext": os.path.splitext(p)[1].lower()} for p in paths],
        "attempted": len(paths),
    }
