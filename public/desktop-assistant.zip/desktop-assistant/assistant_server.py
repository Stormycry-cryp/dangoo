# -*- coding: utf-8 -*-
"""
Dangoo 本地助手 —— HTTP 服务（第一版：剪映批量导入）

运行：
    python assistant_server.py
默认监听 127.0.0.1:19527，仅本机可访问。

设计：
- 零第三方依赖（标准库 http.server），Windows 自带 Python 即可运行；
- 网页（线上 Dangoo）调用 http://127.0.0.1:19527/...，本服务把远程素材
  URL 下载到系统临时目录，.webm 用 FFmpeg 转 .mp4，再复用 jianying_import
  的 Windows 窗口自动化，一次性导入剪映素材库；
- 只允许白名单 Origin（本地开发 + Dangoo 线上域），防止任意网页调用本机；
- 每次导入是一个系统文件对话框动作，成功返回导入的文件清单，单文件失败不影响其它。
"""
import json
import mimetypes
import os
import re
import shutil
import sys
import tempfile
import threading
import traceback
import urllib.parse
import urllib.request
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

import jianying_import as jy
import adobe_import as ai

HOST = os.getenv("DANGOO_ASSISTANT_HOST", "127.0.0.1")
PORT = int(os.getenv("DANGOO_ASSISTANT_PORT", "19527"))
VERSION = "0.2.1"

# 允许调用本助手的网页来源（线上域名按需补充，结尾不带斜杠）。
ALLOWED_ORIGINS = {
    origin.strip().lower()
    for origin in os.getenv(
        "DANGOO_ASSISTANT_ORIGINS",
        "http://localhost:8000,http://127.0.0.1:8000,http://localhost:5173,https://www.runninghub.cn,https://runninghub.cn,https://vibex.runninghub.cn,https://www.vibex.cn,https://vibex.cn",
    ).split(",")
    if origin.strip()
}

# 允许下载的素材域名（RunningHub CDN / 腾讯云 COS / VibeX 应用域等）。留空集合表示不校验 host。
ALLOWED_URL_HOST_SUFFIXES = (
    "runninghub.cn",
    "runninghub.com",
    "myqcloud.com",
    "xiaoyaoyou.com",
    "vibex.cn",
)

IMAGE_EXTS = jy.JIANYING_IMAGE_EXTENSIONS
NATIVE_VIDEO_EXTS = jy.JIANYING_VIDEO_EXTENSIONS  # .mp4/.mov/.m4v
TRANSCODE_EXTS = {".webm"}
MEDIA_EXTS = IMAGE_EXTS | NATIVE_VIDEO_EXTS | TRANSCODE_EXTS

MAX_ITEMS = 64
MAX_DOWNLOAD_BYTES = 500 * 1024 * 1024  # 单文件 500MB 上限
DOWNLOAD_TIMEOUT = 120

# 本次会话的临时工作目录（下载/转码产物），退出时清理。
WORK_DIR = tempfile.mkdtemp(prefix="dangoo-assistant-")


def log(*parts):
    print("[assistant]", *parts, flush=True)


def is_url_allowed(url: str) -> bool:
    try:
        p = urllib.parse.urlparse(url)
    except Exception:
        return False
    if p.scheme not in ("http", "https"):
        return False
    host = (p.hostname or "").lower()
    if not host:
        return False
    # 助手只监听本机回环，允许本地开发/预览域下的应用自有存储地址。
    if host in ("localhost", "127.0.0.1", "[::1]", "::1"):
        return True
    return any(host == s.lstrip("*.") or host.endswith("." + s.lstrip("*.")) for s in ALLOWED_URL_HOST_SUFFIXES)


def safe_filename(name: str, fallback_ext: str) -> str:
    name = os.path.basename(name or "").strip()
    name = re.sub(r'[\\/:*?"<>|\r\n\t]+', "_", name)
    name = name.strip(" .") or ("media" + fallback_ext)
    if len(name) > 120:
        stem, ext = os.path.splitext(name)
        name = stem[:110] + ext
    if not os.path.splitext(name)[1]:
        name += fallback_ext
    return name


def guess_ext(url: str, content_type: str) -> str:
    ext = os.path.splitext(urllib.parse.urlparse(url).path)[1].lower()
    if ext in MEDIA_EXTS:
        return ext
    ct = (content_type or "").split(";")[0].strip().lower()
    guessed = mimetypes.guess_extension(ct) if ct else None
    if guessed == ".jpe":
        guessed = ".jpg"
    return guessed if guessed in MEDIA_EXTS else (".mp4" if ct.startswith("video") else ".png" if ct.startswith("image") else "")


def download_item(item: dict, index: int) -> dict:
    """下载单个素材；webm 转码为 mp4。返回 {ok, path?, name?, error?, code?}。"""
    url = str(item.get("url") or "").strip()
    if not url:
        return {"ok": False, "code": "missing_url", "error": "第 %d 项缺少 url" % (index + 1)}
    if not is_url_allowed(url):
        return {"ok": False, "code": "url_not_allowed", "error": "不允许的素材地址（域名不在白名单）", "url": url}

    try:
        req = urllib.request.Request(url, headers={
            "User-Agent": "DangooAssistant/%s" % VERSION,
            "Accept": "image/*,video/*,*/*;q=0.8",
        })
        with urllib.request.urlopen(req, timeout=DOWNLOAD_TIMEOUT) as resp:
            content_type = resp.headers.get("Content-Type", "")
            ext = guess_ext(url, content_type)
            if not ext:
                return {"ok": False, "code": "unsupported_format", "error": "无法识别的素材类型", "url": url}
            name = safe_filename(str(item.get("name") or urllib.parse.urlparse(url).path), ext)
            # 防重名
            target = os.path.join(WORK_DIR, "%02d_%s" % (index + 1, name))
            written = 0
            with open(target, "wb") as f:
                while True:
                    chunk = resp.read(1 << 16)
                    if not chunk:
                        break
                    written += len(chunk)
                    if written > MAX_DOWNLOAD_BYTES:
                        f.close()
                        os.remove(target)
                        return {"ok": False, "code": "file_too_large", "error": "素材超过大小上限", "url": url}
                    f.write(chunk)

        local_ext = os.path.splitext(target)[1].lower()
        final_path = target
        final_name = os.path.basename(target)
        if local_ext in TRANSCODE_EXTS:
            stem = os.path.splitext(target)[0]
            out_path = stem + ".mp4"
            try:
                jy.transcode_video_for_jianying(target, out_path)
            except Exception as exc:
                return {"ok": False, "code": "transcode_failed", "error": str(exc), "url": url}
            final_path, final_name = out_path, os.path.basename(out_path)
        elif local_ext not in IMAGE_EXTS | NATIVE_VIDEO_EXTS:
            return {"ok": False, "code": "unsupported_format", "error": "不支持的格式: %s" % local_ext, "url": url}

        return {"ok": True, "path": final_path, "name": final_name, "ext": os.path.splitext(final_path)[1].lower()}
    except Exception as exc:
        return {"ok": False, "code": "download_failed", "error": str(exc), "url": url}


def detect_jianying() -> dict:
    """尽力检测剪映是否在运行（非 Windows / 未运行返回 ok=false，不抛异常）。"""
    if os.name != "nt":
        return {"running": False, "platform_supported": False}
    try:
        import ctypes
        from ctypes import wintypes
        user32 = ctypes.windll.user32
        kernel32 = ctypes.windll.kernel32
        user32.GetForegroundWindow.restype = wintypes.HWND
        _, _, exe = jy._find_jianying_window(user32, kernel32)
        return {"running": True, "platform_supported": True, "executable": exe}
    except Exception as exc:
        code = getattr(exc, "code", "not_running")
        return {"running": False, "platform_supported": True, "code": code, "message": str(exc)}


def download_image_item(item: dict, index: int) -> dict:
    """Adobe 专用：只下载图片（视频在 PS/AI 里无意义），复用 download_item 后做类型剔除。"""
    r = download_item(item, index)
    if r.get("ok") and r.get("ext") not in IMAGE_EXTS:
        return {"ok": False, "code": "unsupported_format", "error": "Adobe 只接受图片（png/jpg/webp 等）", "url": r.get("url", item.get("url"))}
    return r


def do_adobe_import(application: str, items: list) -> dict:
    app = (application or "").strip().lower()
    if app not in ai.SUPPORTED:
        return {"ok": False, "code": "invalid_application", "message": "不支持的 Adobe 应用: %r" % application}
    # 非 Windows 在下载前短路，避免准备好素材却无法执行桌面自动化
    if os.name != "nt":
        return {"ok": False, "code": "unsupported_platform",
                "message": "Adobe 导入仅支持 Windows（需已安装 %s）" % (
                    "Photoshop" if app == "photoshop" else "Illustrator")}

    results = [download_image_item(item, i) for i, item in enumerate(items[:MAX_ITEMS])]
    ready = [r for r in results if r.get("ok")]
    failed = [
        {"ok": False, "code": r.get("code", "error"), "error": r.get("error"), "url": r.get("url")}
        for r in results if not r.get("ok")
    ]
    if not ready:
        return {"ok": False, "code": "no_media", "message": "没有可导入的图片", "imported": [], "failed": failed}

    try:
        ai.import_images_to_adobe(app, [r["path"] for r in ready])
    except ai.AdobeImportError as exc:
        status_code = 400 if exc.code in (
            "invalid_application", "no_media", "no_active_document", "invalid_image", "image_not_found",
        ) else 502
        return {
            "ok": False, "code": exc.code, "message": exc.message,
            "failed": failed, "_http_status": status_code,
        }
    except Exception as exc:  # 兜底，不让异常变成 500 空响应
        traceback.print_exc()
        return {"ok": False, "code": "adobe_error", "message": str(exc) or "Adobe 导入失败", "failed": failed, "_http_status": 502}

    return {
        "ok": True, "code": "ok", "application": app,
        "message": "已导入 %d 张图片到 %s" % (
            len(ready), "Photoshop" if app == "photoshop" else "Illustrator"),
        "imported": [{"name": r["name"], "ext": r["ext"]} for r in ready],
        "failed": failed, "attempted": len(ready),
    }


def do_import(items: list) -> dict:
    # 第一步：下载 + 转码（平台无关，非 Windows 也能验证素材准备是否成功）
    results = [download_item(item, i) for i, item in enumerate(items[:MAX_ITEMS])]
    ready = [r for r in results if r.get("ok")]
    failed = [
        {"ok": False, "code": r.get("code", "error"), "error": r.get("error"), "url": r.get("url")}
        for r in results if not r.get("ok")
    ]

    if not ready:
        return {"ok": False, "code": "no_media", "message": "没有可导入的素材", "results": results, "imported": []}

    # 第二步：素材齐了，才要求 Windows + 剪映并执行桌面自动化
    if os.name != "nt":
        return {
            "ok": False, "code": "unsupported_platform",
            "message": "本地助手仅支持 Windows 上的剪映导入（素材已准备好：%d 个）" % len(ready),
            "ready_count": len(ready), "failed": [
                {"code": r.get("code"), "error": r.get("error"), "url": r.get("url")} for r in results if not r.get("ok")
            ],
        }

    paths = [r["path"] for r in ready]
    imported = []
    import_error = None
    try:
        # 一次性（一个系统文件对话框）导入全部素材
        jy.import_media_batch_to_jianying(paths)
        imported = [{"name": r["name"], "ext": r["ext"]} for r in ready]
    except Exception as exc:
        import_error = {
            "code": getattr(exc, "code", "jianying_error"),
            "status_code": getattr(exc, "status_code", 502),
            "message": str(exc),
        }

    return {
        "ok": import_error is None,
        "code": import_error["code"] if import_error else "ok",
        "message": import_error["message"] if import_error else "已导入 %d 个素材到剪映" % len(imported),
        "imported": imported,
        "failed": failed,
        "attempted": len(ready),
    }


class Handler(BaseHTTPRequestHandler):
    server_version = "DangooAssistant/%s" % VERSION

    def _cors(self, pna=False):
        origin = self.headers.get("Origin", "")
        if origin.lower() in ALLOWED_ORIGINS:
            self.send_header("Access-Control-Allow-Origin", origin)
            self.send_header("Vary", "Origin")
            self.send_header("Access-Control-Allow-Methods", "GET, POST, OPTIONS")
            self.send_header("Access-Control-Allow-Headers", "Content-Type")
            self.send_header("Access-Control-Max-Age", "86400")
            # Chrome 专用网络访问(PNA): https 页面 POST 本机回环时,
            # 预检必须显式放行, 否则浏览器静默拦截 POST(表现为健康检测正常、点导出无反应)。
            pn = self.headers.get("Access-Control-Request-Private-Network", "")
            if pna or pn:
                self.send_header("Access-Control-Allow-Private-Network", "true")

    def _json(self, payload: dict, status: int = 200):
        body = json.dumps(payload, ensure_ascii=False).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self._cors()
        self.end_headers()
        self.wfile.write(body)

    def log_message(self, fmt, *args):
        log("%s - %s" % (self.address_string(), fmt % args))

    def do_OPTIONS(self):
        self.send_response(204)
        self._cors(pna=True)
        self.end_headers()

    def do_GET(self):
        path = urllib.parse.urlparse(self.path).path
        if path in ("/", "/health"):
            self._json({
                "ok": True,
                "service": "dangoo-desktop-assistant",
                "version": VERSION,
                "capabilities": ["jianying.batch_import", "adobe.import"],
                "jianying": detect_jianying(),
                "photoshop": ai.detect_adobe("photoshop"),
                "illustrator": ai.detect_adobe("illustrator"),
            })
        else:
            self._json({"ok": False, "code": "not_found"}, 404)

    def do_POST(self):
        path = urllib.parse.urlparse(self.path).path
        length = int(self.headers.get("Content-Length") or 0)
        try:
            raw = self.rfile.read(length) if length else b"{}"
            data = json.loads(raw.decode("utf-8") or "{}")
        except Exception:
            self._json({"ok": False, "code": "bad_json", "message": "请求体不是合法 JSON"}, 400)
            return

        if path == "/api/jianying/import":
            items = data.get("items")
            # 兼容 {urls:[...]} 和单个 {url}
            if items is None and isinstance(data.get("urls"), list):
                items = [{"url": u} for u in data["urls"]]
            if items is None and data.get("url"):
                items = [{"url": data.get("url"), "name": data.get("name")}]
            if not isinstance(items, list) or not items:
                self._json({"ok": False, "code": "missing_items", "message": "需要 items:[{url,name?}]"}, 400)
                return
            if len(items) > MAX_ITEMS:
                self._json({"ok": False, "code": "too_many_items", "message": "单次最多 %d 个素材" % MAX_ITEMS}, 400)
                return
            try:
                result = do_import(items)
                # 桥接类错误映射成合适的 HTTP 状态，但仍带可读 body
                status = 200 if result.get("ok") else (502 if result.get("code") in (
                    "app_not_running", "activation_failed", "import_dialog_timeout", "import_timeout",
                    "filename_input_not_found", "open_button_not_found", "jianying_error",
                ) else 400)
                self._json(result, status)
            except Exception:
                traceback.print_exc()
                self._json({"ok": False, "code": "internal_error", "message": "助手内部错误"}, 500)

        elif path == "/api/adobe/import":
            application = str(data.get("application") or "").strip().lower()
            items = data.get("items")
            if items is None and data.get("url"):
                items = [{"url": data.get("url"), "name": data.get("name")}]
            if application not in ai.SUPPORTED:
                self._json({"ok": False, "code": "invalid_application",
                            "message": "application 必须是 photoshop 或 illustrator"}, 400)
                return
            if not isinstance(items, list) or not items:
                self._json({"ok": False, "code": "missing_items",
                            "message": "需要 items:[{url,name?}]"}, 400)
                return
            if len(items) > MAX_ITEMS:
                self._json({"ok": False, "code": "too_many_items",
                            "message": "单次最多 %d 个素材" % MAX_ITEMS}, 400)
                return
            try:
                result = do_adobe_import(application, items)
                status = result.pop("_http_status", 200) if isinstance(result, dict) else 200
                self._json(result, status)
            except Exception:
                traceback.print_exc()
                self._json({"ok": False, "code": "internal_error", "message": "助手内部错误"}, 500)
        else:
            self._json({"ok": False, "code": "not_found"}, 404)


def main():
    os.makedirs(WORK_DIR, exist_ok=True)
    server = ThreadingHTTPServer((HOST, PORT), Handler)
    log("Dangoo 本地助手 v%s 已启动: http://%s:%d" % (VERSION, HOST, PORT))
    log("临时目录:", WORK_DIR)
    log("允许来源:", ", ".join(sorted(ALLOWED_ORIGINS)))
    jy_info = detect_jianying()
    log("剪映状态:", "运行中" if jy_info.get("running") else "未检测到（请先打开剪映并进入工程）")
    for app_name, label in (("photoshop", "Photoshop"), ("illustrator", "Illustrator")):
        info = ai.detect_adobe(app_name)
        if not info.get("platform_supported"):
            log("%s: 当前系统不支持（仅 Windows）" % label)
        else:
            log("%s 状态:" % label, "运行中" if info.get("running") else "未检测到（导入时会自动尝试唤起）")
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        log("正在退出…")
    finally:
        server.server_close()
        shutil.rmtree(WORK_DIR, ignore_errors=True)


if __name__ == "__main__":
    main()
