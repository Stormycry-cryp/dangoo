import ctypes
import os
import shutil
import subprocess
import time
from ctypes import wintypes
from threading import Lock


JIANYING_PROCESS_NAMES = {"jianyingpro.exe", "capcut.exe"}
JIANYING_IMPORT_TIMEOUT_SECONDS = 15
JIANYING_DIALOG_SETTLE_SECONDS = 0.15
JIANYING_IMPORT_CONFIRM_RETRY_SECONDS = 0.8
VIDEO_TRANSCODE_TIMEOUT_SECONDS = 300
JIANYING_IMAGE_EXTENSIONS = {".bmp", ".gif", ".jpeg", ".jpg", ".png", ".tif", ".tiff", ".webp"}
JIANYING_VIDEO_EXTENSIONS = {".m4v", ".mov", ".mp4"}
WINDOWS_FILE_DIALOG_FILENAME_CONTROL_IDS = (0x047C, 0x0480)

_JIANYING_IMPORT_LOCK = Lock()


class JianyingImportError(Exception):
    def __init__(self, message, status_code=502, code="jianying_error"):
        super().__init__(message)
        self.status_code = status_code
        self.code = code


def _ffmpeg_executable():
    configured = str(os.getenv("FFMPEG_BINARY") or "").strip()
    candidates = [
        configured,
        shutil.which("ffmpeg.exe"),
        shutil.which("ffmpeg"),
        r"D:\ffmpeg\bin\ffmpeg.exe",
    ]
    return next((path for path in candidates if path and os.path.isfile(path)), None)


def transcode_video_for_jianying(source_path, output_path):
    ffmpeg = _ffmpeg_executable()
    if not ffmpeg:
        raise JianyingImportError("未找到 FFmpeg，无法将画布视频转换为剪映兼容格式", 501, "ffmpeg_unavailable")
    os.makedirs(os.path.dirname(output_path), exist_ok=True)
    command = [
        ffmpeg,
        "-y",
        "-hide_banner",
        "-loglevel",
        "error",
        "-i",
        source_path,
        "-map",
        "0:v:0",
        "-map",
        "0:a?",
        "-vf",
        "scale=trunc(iw/2)*2:trunc(ih/2)*2",
        "-c:v",
        "libx264",
        "-preset",
        "medium",
        "-crf",
        "18",
        "-pix_fmt",
        "yuv420p",
        "-c:a",
        "aac",
        "-b:a",
        "192k",
        "-movflags",
        "+faststart",
        output_path,
    ]
    creation_flags = getattr(subprocess, "CREATE_NO_WINDOW", 0)
    try:
        completed = subprocess.run(
            command,
            capture_output=True,
            timeout=VIDEO_TRANSCODE_TIMEOUT_SECONDS,
            check=False,
            creationflags=creation_flags,
        )
    except subprocess.TimeoutExpired as exc:
        raise JianyingImportError("画布视频转码超时", 504, "transcode_timeout") from exc
    if completed.returncode != 0 or not os.path.isfile(output_path) or os.path.getsize(output_path) < 1:
        message = completed.stderr.decode("utf-8", errors="replace").strip()
        raise JianyingImportError(message or "画布视频转码失败", 502, "transcode_failed")
    return {
        "filename": os.path.basename(output_path),
        "size": os.path.getsize(output_path),
    }


def _window_executable(user32, kernel32, hwnd):
    pid = wintypes.DWORD()
    user32.GetWindowThreadProcessId(hwnd, ctypes.byref(pid))
    process = kernel32.OpenProcess(0x1000, False, pid.value)
    if not process:
        return pid.value, ""
    try:
        size = wintypes.DWORD(32768)
        buffer = ctypes.create_unicode_buffer(size.value)
        if not kernel32.QueryFullProcessImageNameW(process, 0, buffer, ctypes.byref(size)):
            return pid.value, ""
        return pid.value, buffer.value
    finally:
        kernel32.CloseHandle(process)


def _find_jianying_window(user32, kernel32):
    candidates = []
    callback_type = ctypes.WINFUNCTYPE(wintypes.BOOL, wintypes.HWND, wintypes.LPARAM)

    @callback_type
    def visit(hwnd, _):
        if not user32.IsWindowVisible(hwnd):
            return True
        pid, executable = _window_executable(user32, kernel32, hwnd)
        if os.path.basename(executable).lower() not in JIANYING_PROCESS_NAMES:
            return True
        rect = wintypes.RECT()
        if not user32.GetWindowRect(hwnd, ctypes.byref(rect)):
            return True
        area = max(0, rect.right - rect.left) * max(0, rect.bottom - rect.top)
        if area:
            candidates.append((area, hwnd, pid, executable))
        return True

    user32.EnumWindows(visit, 0)
    if not candidates:
        raise JianyingImportError("未检测到已打开的剪映专业版", 409, "app_not_running")
    _, hwnd, pid, executable = max(candidates, key=lambda item: item[0])
    return hwnd, pid, executable


def _send_key(user32, key, key_up=False):
    user32.keybd_event(key, 0, 0x0002 if key_up else 0, 0)


def _send_hotkey(user32, modifier, key):
    _send_key(user32, modifier)
    _send_key(user32, key)
    _send_key(user32, key, True)
    _send_key(user32, modifier, True)


def _foreground_pid(user32):
    hwnd = user32.GetForegroundWindow()
    pid = wintypes.DWORD()
    if hwnd:
        user32.GetWindowThreadProcessId(hwnd, ctypes.byref(pid))
    return hwnd, pid.value


def _window_class(user32, hwnd):
    buffer = ctypes.create_unicode_buffer(256)
    user32.GetClassNameW(hwnd, buffer, len(buffer))
    return buffer.value


def _wait_for_import_dialog(user32, pid, main_window):
    deadline = time.monotonic() + JIANYING_IMPORT_TIMEOUT_SECONDS
    while time.monotonic() < deadline:
        hwnd, foreground_pid = _foreground_pid(user32)
        if hwnd and hwnd != main_window and foreground_pid == pid and _window_class(user32, hwnd) == "#32770":
            return hwnd
        time.sleep(0.1)
    raise JianyingImportError("剪映没有打开媒体导入窗口，请确认当前已打开项目", 504, "import_dialog_timeout")


def _find_import_dialog(user32, pid):
    dialogs = []
    callback_type = ctypes.WINFUNCTYPE(wintypes.BOOL, wintypes.HWND, wintypes.LPARAM)

    @callback_type
    def visit(hwnd, _):
        window_pid = wintypes.DWORD()
        user32.GetWindowThreadProcessId(hwnd, ctypes.byref(window_pid))
        if (
            window_pid.value == pid
            and user32.IsWindowVisible(hwnd)
            and _window_class(user32, hwnd) == "#32770"
        ):
            dialogs.append(hwnd)
        return True

    user32.EnumWindows(visit, 0)
    return dialogs[0] if dialogs else 0


def _find_dialog_control(user32, dialog, class_name, visible=True):
    controls = []
    callback_type = ctypes.WINFUNCTYPE(wintypes.BOOL, wintypes.HWND, wintypes.LPARAM)

    @callback_type
    def visit(hwnd, _):
        if (not visible or user32.IsWindowVisible(hwnd)) and user32.IsWindowEnabled(hwnd):
            if _window_class(user32, hwnd) == class_name:
                controls.append(hwnd)
        return True

    user32.EnumChildWindows(dialog, visit, 0)
    return controls[0] if controls else 0


def _find_filename_control(user32, dialog):
    for control_id in WINDOWS_FILE_DIALOG_FILENAME_CONTROL_IDS:
        control = user32.GetDlgItem(dialog, control_id)
        if control and user32.IsWindowVisible(control) and user32.IsWindowEnabled(control):
            return control

    edits = []
    callback_type = ctypes.WINFUNCTYPE(wintypes.BOOL, wintypes.HWND, wintypes.LPARAM)

    @callback_type
    def visit(hwnd, _):
        if (
            _window_class(user32, hwnd) == "Edit"
            and user32.IsWindowVisible(hwnd)
            and user32.IsWindowEnabled(hwnd)
        ):
            rect = wintypes.RECT()
            if user32.GetWindowRect(hwnd, ctypes.byref(rect)):
                edits.append((rect.top, hwnd))
        return True

    user32.EnumChildWindows(dialog, visit, 0)
    return max(edits, default=(0, 0), key=lambda item: item[0])[1]


def _activate_window(user32, hwnd, pid):
    # SW_RESTORE changes a maximized Jianying window back to its normal size.
    # Only restore an actually minimized window; otherwise preserve the user's
    # current window size and maximized state while bringing it to the front.
    if user32.IsIconic(hwnd):
        user32.ShowWindow(hwnd, 9)
    _send_key(user32, 0x12)
    _send_key(user32, 0x12, True)
    user32.BringWindowToTop(hwnd)
    user32.SetForegroundWindow(hwnd)
    time.sleep(0.5)
    foreground, foreground_pid = _foreground_pid(user32)
    if foreground != hwnd or foreground_pid != pid:
        raise JianyingImportError("无法激活剪映窗口，请关闭其他置顶窗口后重试", 409, "activation_failed")


def _open_media_in_dialog(user32, dialog, path):
    paths = [path] if isinstance(path, str) else [item for item in path if item]
    if not paths:
        raise JianyingImportError("待导入的媒体文件不存在", 404, "media_not_found")
    deadline = time.monotonic() + JIANYING_IMPORT_TIMEOUT_SECONDS
    filename_input = 0
    while time.monotonic() < deadline and user32.IsWindow(dialog):
        filename_input = _find_filename_control(user32, dialog)
        if filename_input:
            break
        time.sleep(0.1)
    if not filename_input:
        raise JianyingImportError("无法定位剪映导入窗口的文件名输入框", 502, "filename_input_not_found")
    # The Windows common file dialog accepts quoted absolute paths separated
    # by spaces, which selects all files in one Open action.
    dialog_value = os.path.abspath(paths[0]) if len(paths) == 1 else " ".join(
        f'"{os.path.abspath(item)}"' for item in paths
    )
    path_buffer = ctypes.create_unicode_buffer(dialog_value)
    user32.SendMessageW(filename_input, 0x000C, 0, ctypes.addressof(path_buffer))
    time.sleep(JIANYING_DIALOG_SETTLE_SECONDS)
    open_button = user32.GetDlgItem(dialog, 1)
    if not open_button:
        open_button = _find_dialog_control(user32, dialog, "Button")
    if not open_button:
        raise JianyingImportError("无法定位剪映导入窗口的打开按钮", 502, "open_button_not_found")
    user32.SendMessageW(open_button, 0x00F5, 0, 0)
    deadline = time.monotonic() + JIANYING_IMPORT_TIMEOUT_SECONDS
    retry_at = time.monotonic() + JIANYING_IMPORT_CONFIRM_RETRY_SECONDS
    retried = False
    while time.monotonic() < deadline:
        if not user32.IsWindow(dialog) or not user32.IsWindowVisible(dialog):
            return
        if not retried and time.monotonic() >= retry_at:
            retry_button = user32.GetDlgItem(dialog, 1) or open_button
            if retry_button and user32.IsWindowVisible(retry_button) and user32.IsWindowEnabled(retry_button):
                user32.SendMessageW(retry_button, 0x00F5, 0, 0)
            retried = True
        time.sleep(0.1)
    raise JianyingImportError("剪映没有完成素材导入，请检查是否出现了确认窗口", 504, "import_timeout")


def import_media_to_jianying(path):
    return _import_media_paths_to_jianying([path], batch=False)


def import_media_batch_to_jianying(paths):
    return _import_media_paths_to_jianying(paths, batch=True)


def _import_media_paths_to_jianying(paths, batch=False):
    paths = [path for path in (paths or []) if path]
    if not paths:
        raise JianyingImportError("待导入的媒体文件不存在", 404, "media_not_found")
    if os.name != "nt":
        raise JianyingImportError("剪映直接导入目前仅支持 Windows", 501, "unsupported_platform")
    for path in paths:
        if not os.path.isfile(path):
            raise JianyingImportError("待导入的媒体文件不存在", 404, "media_not_found")
        extension = os.path.splitext(path)[1].lower()
        if extension not in JIANYING_IMAGE_EXTENSIONS | JIANYING_VIDEO_EXTENSIONS:
            raise JianyingImportError("剪映桥接不支持当前图片或视频格式", 400, "unsupported_format")
    if not _JIANYING_IMPORT_LOCK.acquire(timeout=1):
        raise JianyingImportError("另一个剪映导入任务仍在进行", 409, "busy")
    try:
        user32 = ctypes.windll.user32
        kernel32 = ctypes.windll.kernel32
        user32.GetForegroundWindow.restype = wintypes.HWND
        user32.GetDlgItem.restype = wintypes.HWND
        user32.SendMessageW.argtypes = [wintypes.HWND, wintypes.UINT, wintypes.WPARAM, wintypes.LPARAM]
        user32.SendMessageW.restype = wintypes.LPARAM
        kernel32.OpenProcess.argtypes = [wintypes.DWORD, wintypes.BOOL, wintypes.DWORD]
        kernel32.OpenProcess.restype = wintypes.HANDLE
        kernel32.CloseHandle.argtypes = [wintypes.HANDLE]
        kernel32.QueryFullProcessImageNameW.argtypes = [
            wintypes.HANDLE,
            wintypes.DWORD,
            wintypes.LPWSTR,
            ctypes.POINTER(wintypes.DWORD),
        ]
        main_window, pid, executable = _find_jianying_window(user32, kernel32)
        dialog = _find_import_dialog(user32, pid)
        if not dialog:
            _activate_window(user32, main_window, pid)
            _send_hotkey(user32, 0x11, 0x49)
            dialog = _wait_for_import_dialog(user32, pid, main_window)
        _open_media_in_dialog(user32, dialog, paths if batch else paths[0])
        result = {
            "ok": True,
            "code": "ok",
            "message": "已导入剪映素材库",
            "application": "jianying",
            "process_id": pid,
            "version_path": executable,
            "filename": os.path.basename(paths[0]),
        }
        if batch:
            result["filenames"] = [os.path.basename(path) for path in paths]
            result["count"] = len(paths)
        return result
    finally:
        _JIANYING_IMPORT_LOCK.release()


def import_video_to_jianying(path):
    return import_media_to_jianying(path)
