# Dangoo 本地助手（v0.3：免安装 Python，解压即用）

跑在你自己 Windows 电脑上的一个小程序。线上 Dangoo 网页通过 `http://127.0.0.1:19527`
调用它：

- 把选中的图片/视频**一键导入剪映专业版素材库**；
- 把选中的图片**一键导入 Photoshop 或 Illustrator**。

> 为什么需要它：云端网页碰不到你电脑上的软件，桌面自动化必须在本机执行。
> 剪映链路：下载素材 → webm 转 mp4 → 操作剪映导入窗口；
> Adobe 链路：下载图片 → 经 PowerShell 调用 Photoshop/Illustrator 官方接口置入。

## 一、开始使用

1. **Windows 10/11** 即可，**不需要安装 Python**——压缩包里的 `python-runtime`
   已自带整套运行环境（Python 3.12）。
2. 把压缩包解压到任意目录（比如 `D:\dangoo-assistant`），不要放在含中文或
   空格的路径下。
3. 双击 `start.bat`，黑色窗口显示“运行中”即成功，保持开着，最小化即可。
4. 用剪映导入时：已安装**剪映专业版**（或国际版 CapCut），并已打开、
   已进入一个草稿/工程（停在剪辑界面，不是首页）。
5. 用 Adobe 导入时：已安装 **Photoshop** 和/或 **Illustrator**，并已打开一个
   文档或画板（没有文档时，第一张会直接打开，其余继续置入）。
6. 视频里若有 `.webm`，需要 **FFmpeg**（会自动转成 mp4）。三种提供方式任选：
   - 放到 `D:\ffmpeg\bin\ffmpeg.exe`；
   - 或让 ffmpeg 在系统 PATH 里；
   - 或设置环境变量 `FFMPEG_BINARY` 指向 ffmpeg.exe。
   - 纯图片 / mp4 / mov / m4v，以及 Adobe 导入，都不需要 FFmpeg。

## 二、启动

双击 `start.bat` 即可。看到下面输出即成功：

```
[assistant] Dangoo 本地助手 v0.3.0 已启动: http://127.0.0.1:19527
[assistant] 剪映状态: 运行中
[assistant] Photoshop 状态: 运行中
[assistant] Illustrator 状态: 未检测到（导入时会自动尝试唤起）
```

保持这个窗口开着即可。健康检查：浏览器打开 <http://127.0.0.1:19527/health>，
返回 JSON，里面 `jianying.running` / `photoshop.running` / `illustrator.running`
表示各软件是否已识别。首次 health 检测可能要几秒。

> 运行时说明：`python-runtime` 是官方 Windows Python 3.12 的完整标准库运行环境，
> 不含第三方包也不需要联网，脚本只用到 Python 标准库，全程离线运行。

## 三、接口（供网页调用 / 也可手动联调）

### GET /health
返回服务版本，以及剪映、Photoshop、Illustrator 的运行/平台支持状态。

### POST /api/jianying/import
请求体（推荐）：
```json
{ "items": [ { "url": "https://….png", "name": "图1.png" } ] }
```
也兼容：`{ "urls": ["https://….png", "https://….mp4"] }` 和单个 `{ "url": "…" }`。

- 单次最多 64 个素材；
- 只接受白名单域名（RunningHub / 腾讯云 COS / VibeX 应用域 / 本机），防止任意网页让助手下载文件；
- `.webm` 自动转 `.mp4`（H.264 / AAC / yuv420p / 偶数宽高 / faststart）；
- 一个系统文件对话框一次性导入全部素材。

### POST /api/adobe/import
请求体：
```json
{ "application": "photoshop",
  "items": [ { "url": "https://….png", "name": "图1.png" } ] }
```
`application` 只能是 `photoshop` 或 `illustrator`；只接受图片，视频会被剔除。
有活动文档时逐张置入为新图层/对象；没有文档时第一张直接打开。

成功返回：
```json
{ "ok": true, "code": "ok", "message": "已导入 2 张图片到 Photoshop",
  "imported": [{"name":"a.png","ext":".png"}], "failed": [], "attempted": 2 }
```

常见错误码（前端可翻译成中文）：
- 剪映：`app_not_running` / `activation_failed` / `import_dialog_timeout` /
  `ffmpeg_unavailable` / `transcode_failed`；
- Adobe：`invalid_application`（应用名非法）、`app_not_running`（没装或连不上）、
  `no_active_document`（先打开一个文档/画板）、`image_not_found`、
  `timeout`（Adobe 卡住或有弹窗）、`powershell_unavailable`、`adobe_error`；
- 通用：`url_not_allowed`（域名不在白名单）、`unsupported_platform`（不是 Windows）、
  `unsupported_format`、`no_media`、`partial_failure`（部分成功）。

## 四、命令行自测（不用网页）

PowerShell：

```powershell
# 剪映
$body = '{"items":[{"url":"https://你的素材地址/test.mp4"}]}'
Invoke-RestMethod -Uri http://127.0.0.1:19527/api/jianying/import -Method Post -ContentType "application/json" -Body $body

# Photoshop
$body = '{"application":"photoshop","items":[{"url":"https://你的素材地址/a.png"}]}'
Invoke-RestMethod -Uri http://127.0.0.1:19527/api/adobe/import -Method Post -ContentType "application/json" -Body $body
```

## 五、可调配置（环境变量）

| 变量 | 默认 | 说明 |
|---|---|---|
| `DANGOO_ASSISTANT_HOST` | `127.0.0.1` | 监听地址，保持 127.0.0.1 最安全 |
| `DANGOO_ASSISTANT_PORT` | `19527` | 端口 |
| `DANGOO_ASSISTANT_ORIGINS` | 本地 + runninghub/vibex 域 | 允许调用的网页来源，逗号分隔 |
| `FFMPEG_BINARY` | 空 | ffmpeg.exe 完整路径 |

## 六、安全说明

- 只监听 `127.0.0.1`，局域网/外网访问不到；
- 校验请求来源 Origin（白名单），并限制可下载的素材域名；
- 下载/转码产物放在系统临时目录，助手退出时自动清理；
- Adobe 自动化仅按你点击的按钮执行，不会自行操作其它文件；
- 全程不经过任何第三方服务器，素材只在你本机和 RunningHub 之间流转。

## 七、文件

- `start.bat`：一键启动（调用包内 Python，无需安装）；
- `assistant_server.py`：本地 HTTP 服务（下载、转码、调度、健康检测）；
- `adobe_import.py`：Photoshop / Illustrator 的 PowerShell COM 自动化；
- `jianying_import.py`：剪映 Windows 窗口自动化 + FFmpeg 转码；
- `python-runtime/`：内置的 Python 3.12 运行环境（官方发行版，离线可用）。

## 已知限制 / 后续

- Adobe 自动化依赖软件随安装注册的官方 COM 接口；绿色版/精简版若没注册会报 `app_not_running`；
- 首次连接 Adobe 时可能自动启动软件，需等它完全打开、没有启动弹窗；
- 后续：压缩后用单文件 exe 更进一步（内置运行时已具备条件，待 Windows 侧打包工具确认）。
